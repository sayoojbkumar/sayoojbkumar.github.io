#!/bin/sh

node /app/index.js &

sleep 300